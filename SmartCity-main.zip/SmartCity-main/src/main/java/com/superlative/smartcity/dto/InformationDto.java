package com.superlative.smartcity.dto;

import java.sql.Blob;

public class InformationDto {

    private Long id;
    private String title;
    private String location;
    private String category;
    private String description;
    private String imageExt;
    private Blob imageByte;

    public InformationDto() {
    }

    public InformationDto(Long id, String title, String location, String category, String description, String imageExt, Blob imageByte) {
        this.id = id;
        this.title = title;
        this.location = location;
        this.category = category;
        this.description = description;
        this.imageExt = imageExt;
        this.imageByte = imageByte;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the imageExt
     */
    public String getImageExt() {
        return imageExt;
    }

    /**
     * @param imageExt the imageExt to set
     */
    public void setImageExt(String imageExt) {
        this.imageExt = imageExt;
    }

    /**
     * @return the imageByte
     */
    public Blob getImageByte() {
        return imageByte;
    }

    /**
     * @param imageByte the imageByte to set
     */
    public void setImageByte(Blob imageByte) {
        this.imageByte = imageByte;
    }

}
