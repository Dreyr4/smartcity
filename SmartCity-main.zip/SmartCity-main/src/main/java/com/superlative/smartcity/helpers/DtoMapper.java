/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.superlative.smartcity.helpers;

import com.superlative.smartcity.dto.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class DtoMapper {

    public static List<UserDto> mapUserDto(ResultSet resultSet) throws SQLException {
        List<UserDto> response = new ArrayList<>();
        while (resultSet.next()) {
            UserDto userDto = new UserDto();
            userDto.setId(resultSet.getLong("id"));
            userDto.setEmail("email");
            userDto.setFullName("full_name");
            userDto.setMobile("mobile");
            userDto.setRole("role");
            response.add(userDto);
        }
        return response;
    }

    public static List<InformationDto> mapInformationDto(ResultSet resultSet) throws SQLException {
        List<InformationDto> response = new ArrayList<>();
        while (resultSet.next()) {
            InformationDto informationDto = new InformationDto();
            informationDto.setId(resultSet.getLong("id"));
            informationDto.setTitle(resultSet.getString("title"));
            informationDto.setLocation(resultSet.getString("location"));
            informationDto.setCategory(resultSet.getString("category"));
            informationDto.setDescription(resultSet.getString("description"));
            informationDto.setImageExt(resultSet.getString("image_ext"));
            informationDto.setImageByte(resultSet.getBlob("imageByte"));
            response.add(informationDto);
        }
        return response;
    }
}
