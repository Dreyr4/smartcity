package com.superlative.smartcity.helpers;

import com.superlative.smartcity.dto.InformationDto;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Information extends Database {

    private static final Logger logger = LoggerFactory.getLogger(Database.class);

    public List<InformationDto> getAllInformation() {
        try {
            Connection connection = getConnection();
            String query = "SELECT * FROM information";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<InformationDto> response = DtoMapper.mapInformationDto(resultSet);
            connection.close();
            return response;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return Collections.emptyList();
        }
    }

    public List<InformationDto> getAllInformationByCategory(String category) {
        try {
            Connection connection = getConnection();
            String query = "SELECT * FROM information WHERE category = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, category);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<InformationDto> response = DtoMapper.mapInformationDto(resultSet);
            connection.close();
            return response;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return Collections.emptyList();
        }
    }

    public InformationDto getInformationById(Long id) {
        try {
            Connection connection = getConnection();
            String query = "SELECT * FROM information WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<InformationDto> informationDtoList = DtoMapper.mapInformationDto(resultSet);
            InformationDto response = null;
            if (informationDtoList != null && informationDtoList.size() > 0) {
                response = informationDtoList.get(0);
            }
            connection.close();
            return response;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return null;
        }
    }

    public boolean createInformaton(String title, String location, String category, String description, String imageExt, File file) throws SQLException, FileNotFoundException {
        Connection connection = getConnection();
        String query = "INSERT INTO information(title,location,category,description,image_ext,imageByte) VALUES(?,?,?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, title);
        preparedStatement.setString(2, location);
        preparedStatement.setString(3, category);
        preparedStatement.setString(4, description);
        preparedStatement.setString(5, imageExt);
        if (file != null) {
            FileInputStream fileInputStream = new FileInputStream(file);
            preparedStatement.setBinaryStream(6, fileInputStream, file.length());
        } else {
            preparedStatement.setBinaryStream(6, null);
        }
        preparedStatement.executeUpdate();
        connection.close();
        return true;

    }

    public boolean deleteInformationById(Long id) {
        try {
            Connection connection = getConnection();
            String query = "DELETE FROM information WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, id);
            preparedStatement.executeUpdate();
            connection.close();
            return true;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return false;
        }
    }

    public boolean updateInformationWithImage(Long id, String title, String location, String category, String description, String imageExt, File file) throws SQLException, FileNotFoundException {
        Connection connection = getConnection();
        String query = "UPDATE information SET title = ?,location = ?,category = ?,description = ?,image_ext = ?,imageByte = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, title);
        preparedStatement.setString(2, location);
        preparedStatement.setString(3, category);
        preparedStatement.setString(4, description);
        preparedStatement.setString(5, imageExt);

        FileInputStream fileInputStream = new FileInputStream(file);
        preparedStatement.setBinaryStream(6, fileInputStream, file.length());

        preparedStatement.setLong(7, id);
        preparedStatement.executeUpdate();
        connection.close();
        return true;
    }

    public boolean updateInformation(Long id, String title, String location, String category, String description) throws SQLException, FileNotFoundException {
        Connection connection = getConnection();
        String query = "UPDATE information SET title = ?,location = ?,category = ?,description = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, title);
        preparedStatement.setString(2, location);
        preparedStatement.setString(3, category);
        preparedStatement.setString(4, description);
        preparedStatement.setLong(5, id);
        preparedStatement.executeUpdate();
        connection.close();
        return true;
    }

    public List<InformationDto> searchInformation(String title, String location, String category) {
        try {
            if (category.equalsIgnoreCase("None")) {
                category = "~*";
            }
            if (AppUtilities.stringIsEmpty(title)) {
                title = "~*";
            }
            if (AppUtilities.stringIsEmpty(location)) {
                location = "~*";
            }
            Connection connection = getConnection();
            String query = "SELECT * FROM information WHERE title LIKE ? OR location LIKE ? OR category LIKE ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, "%" + title + "%");
            preparedStatement.setString(2, "%" + location + "%");
            preparedStatement.setString(3, "%" + category + "%");
            ResultSet resultSet = preparedStatement.executeQuery();
            List<InformationDto> response = DtoMapper.mapInformationDto(resultSet);
            connection.close();
            return response;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return Collections.emptyList();
        }
    }
}
