/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.superlative.smartcity.helpers;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class AppUtilities {

    private static final Logger logger = LoggerFactory.getLogger(Database.class);
    public static final String[] EXTENSIONS_ARRAY = {"jpeg", "jpg", "png"};
    public static final List EXTENSIONS_LIST = List.of("jpeg", "jpg", "png");

    public static boolean stringIsEmpty(String string) {
        return (string == null || string.trim().equals(""));
    }

    public static boolean isValidExtension(String fileName) {
        if (stringIsEmpty(fileName)) {
            return false;
        }
        String ext = getFileExtension(fileName);
        return stringExistsInListIgnoreCase(ext, EXTENSIONS_LIST);
    }

    public static String getFileExtension(String fileName) {
        if (stringIsEmpty(fileName)) {
            return "";
        }
        String[] splitted = fileName.split("\\.");
        return splitted[splitted.length - 1];
    }

    public static boolean stringExistsInListIgnoreCase(String string, List<String> list) {
        if (stringIsEmpty(string) || list == null) {
            return false;
        }
        AtomicBoolean response = new AtomicBoolean(false);
        list.forEach(listString -> {
            if (listString.equalsIgnoreCase(string)) {
                response.set(true);
                return;
            }
        });
        return response.get();
    }
}
