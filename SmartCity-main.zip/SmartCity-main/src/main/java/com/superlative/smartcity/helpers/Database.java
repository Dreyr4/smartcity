package com.superlative.smartcity.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Database {

    private static final Logger logger = LoggerFactory.getLogger(Database.class);

    private final String JDBC_URL = "jdbc:mysql://localhost:3306/smart_city";
    private final String USERNAME = "root";
    private final String PASSWORD = "";

    public Connection getConnection() {
        try {
            return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
        } catch (SQLException e) {
            logger.error(e.getMessage());
            return null;
        }
    }
}
