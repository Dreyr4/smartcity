/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.superlative.smartcity.helpers;

import com.superlative.smartcity.dto.UserDto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class User extends Database {

    private static final Logger logger = LoggerFactory.getLogger(Database.class);

    public boolean authorizedUser(String username, String password) {
        try {
            Connection connection = getConnection();
            String query = "SELECT * FROM user WHERE email = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();
            boolean auth = resultSet.next();
            connection.close();
            return auth;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return false;
        }
    }

    public List<UserDto> getAllNoneAdminUsers() {
        try {
            Connection connection = getConnection();
            String query = "SELECT * FROM user WHERE role <> ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, "admin");
            ResultSet resultSet = preparedStatement.executeQuery();
            List<UserDto> response = DtoMapper.mapUserDto(resultSet);
            connection.close();
            return response;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return Collections.emptyList();
        }
    }

    public boolean createUser(String fullName, String email, String mobile, String password, String role) {
        try {
            Connection connection = getConnection();
            String query = "INSERT INTO user(full_name,email,mobile,password,role) VALUES(?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, fullName);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, mobile);
            preparedStatement.setString(4, password);
            preparedStatement.setString(5, role);
            preparedStatement.executeUpdate();
            connection.close();
            return true;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return false;
        }
    }

    public String getRoleByEmail(String email) {
        try {
            Connection connection = getConnection();
            String query = "SELECT role FROM user WHERE email = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();
            String role = null;
            if (resultSet.next()) {
                role = resultSet.getString("role");
            }
            connection.close();
            return role;
        } catch (SQLException ex) {
            logger.error(ex.getMessage());
            return null;
        }
    }
}
